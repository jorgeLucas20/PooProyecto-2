/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.projectgame;

import java.io.InputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author xavie
 */
public class ReController implements Initializable {

    @FXML
    private Label registrados;
    @FXML
    private AnchorPane Color;
    @FXML
    private ImageView fondo;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        label();
        cambiarFondo();
        
        
        
    }    
    
    public void label(){
        System.out.println(Usuario.user);
        registrados.setText(Usuario.user.toString());
        
        
        
        
    }
    
    public void cambiarFondo(){
        Color.setStyle("-fx-background-color: #000000");
        InputStream input= App.class.getResourceAsStream("Imagenes/grassTile.png");
        fondo.setImage(new Image(input));
    }
    
    
}
